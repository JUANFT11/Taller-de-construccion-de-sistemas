	//No realizar cambios a este archivo
   const CONFIG1= 'https://sigapdev-conrecibospre-back.herokuapp.com'   

export default CONFIG1;