
   const CONFIG= 'https://fisigarbage-back.herokuapp.com/'   
   //const CONFIG= 'http://localhost:8080/';
export default CONFIG;
