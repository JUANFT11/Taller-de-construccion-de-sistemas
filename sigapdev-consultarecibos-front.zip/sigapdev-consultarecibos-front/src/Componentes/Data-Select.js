const HEROES= [
    { value: 11, label: 'Codigo1' },
    { value: 12, label: 'Codigo2' },
    { value: 13, label: 'Codigo3' },
    { value: 14, label: 'Codigo4' },
    { value: 15, label: 'Codigo5' },
   ]
;
  
  export default HEROES;