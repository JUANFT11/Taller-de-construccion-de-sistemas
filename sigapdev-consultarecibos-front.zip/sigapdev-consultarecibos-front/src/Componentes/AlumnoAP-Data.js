const ALUMNOAP= [
    { id_alumno: 1,cod_alumno: 15200054,id_programa:10 },
    { id_alumno: 2,cod_alumno: 15200057,id_programa:11},
    { id_alumno: 3,cod_alumno: 15200044,id_programa:12 },
    { id_alumno: 4,cod_alumno: 15200024,id_programa:14 },
    { id_alumno: 5,cod_alumno: 15200014,id_programa:15 },
    { id_alumno: 6,cod_alumno: 15200034,id_programa:16 },
    { id_alumno: 7,cod_alumno: 15200054,id_programa:17 },
    { id_alumno: 8,cod_alumno: 15200094,id_programa:18 },
    { id_alumno: 9,cod_alumno: 15200234,id_programa:19 },
    { id_alumno: 10,cod_alumno: 15200984,id_programa:20 },
    { id_alumno: 11,cod_alumno: 15200678,id_programa:21 },
    { id_alumno: 12,cod_alumno: 15200051,id_programa:22 }   
    
   ]
;

export default ALUMNOAP;