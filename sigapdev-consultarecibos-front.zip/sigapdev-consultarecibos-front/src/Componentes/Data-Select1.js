const HEROES1= [
    { value: 1, label: 'Programa1' },
    { value: 2, label: 'Programa2' },
    { value: 3, label: 'Programa3' },
    { value: 4, label: 'Programa4' },
    { value: 5, label: 'Programa5' },
   ]
;
  
  export default HEROES1;