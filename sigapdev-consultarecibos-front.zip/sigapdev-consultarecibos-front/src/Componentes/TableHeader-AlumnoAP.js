import React from 'react'

class TableHeaderAlumnoAP extends React.Component {

  render() {
    return(
    <thead>
			<tr>     
                <th className="th1">NOMBRE-ALUMNO</th>
                <th className="th1">CODIGO-ALUMNO</th>
                <th className="th1">SIGLA PROGRAMA</th>
            </tr>
	</thead>
    )
  }
}

export default TableHeaderAlumnoAP 