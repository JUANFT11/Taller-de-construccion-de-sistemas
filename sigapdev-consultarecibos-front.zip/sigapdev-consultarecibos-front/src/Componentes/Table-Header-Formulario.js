import React from 'react'

class TableHeaderFomulario extends React.Component {

  render() {
    return(
   
            <thead>
		
        <tr> 
                <th className="th2">N°</th>
                <th className="th2">BENEFICIO</th>
                <th className="th2">VALOR</th>
                {/* <th className="th2">wea</th> */}
                
       </tr>
      
	        </thead>
       
    )
  }
}

export default TableHeaderFomulario