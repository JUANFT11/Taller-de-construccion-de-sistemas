const RECAUDACION= [
    { idRec: 1,concepto: '123456',numero:'123456',facultad:'Ingenieria de Sistemas', fecha: '2015-04-01',moneda : 105 ,importe: 300,
      codigo :["Codigo1","Codigo2","Codigo3"],programa :["Programa1","Programa2","Programa3"]
    },
    { idRec: 2,concepto: '123456',numero:'123456',facultad:'Ingenieria de Sistemas', fecha: '2015-04-01',moneda : 105 ,importe: 300,
      codigo :["Codigo1","Codigo2","Codigo3"],programa :["Programa1","Programa2","Programa3"]
  },
    { idRec: 3,concepto: '123456',numero:'123456',facultad:'Ingenieria de Sistemas', fecha: '2015-04-01' ,moneda : 105 ,importe: 300,
    codigo :["Codigo1","Codigo2","Codigo3"],programa :["Programa1","Programa2","Programa3"]
  },
    { idRec: 4,concepto: '123456',numero:'123456',facultad:'Ingenieria de Sistemas', fecha: '2015-04-01',moneda : 105 ,importe: 300,
    codigo :["Codigo1","Codigo2","Codigo3"],programa :["Programa1","Programa2","Programa3"]
  },
    { idRec: 5,concepto: '123456',numero:'123456',facultad:'Ingenieria de Sistemas', fecha: '2015-04-01',moneda : 105 ,importe: 300,
    codigo :["Codigo1","Codigo2","Codigo3"],programa :["Programa1","Programa2","Programa3"]
  },
    { idRec: 6,concepto: '123456',numero:'123456',facultad:'Ingenieria de Sistemas', fecha: '2015-04-01' ,moneda : 105 ,importe: 300,
    codigo :["Codigo1","Codigo2","Codigo3"],programa :["Programa1","Programa2","Programa3"]
  },
    { idRec: 7,concepto: '123456',numero:'123456',facultad:'Ingenieria de Sistemas', fecha: '2015-04-01',moneda : 105 ,importe: 300,
    codigo :["Codigo1","Codigo2","Codigo3"],programa :["Programa1","Programa2","Programa3"]
  },
    
   ]
;
  
  export default RECAUDACION;